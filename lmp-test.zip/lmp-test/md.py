from ase import units
from ase.md.langevin import Langevin
from ase.io import read, write
import numpy as np
import time

from mace.calculators import MACECalculator
import os
from ase.md import MDLogger, velocitydistribution
from ase.io import read, write
#os.system('source ~/software/mace-venv/bin/activate')
t1 = time.time()
out = 'mace_water1593_300K_NVT'
interval = 1000
Temp = 300

calculator = MACECalculator(model_path='../water1593.model', device='cuda', default_dtype="float32")
init_conf = read('h2o.xyz', format='xyz')
init_conf.set_pbc( (True, True, True) )
init_conf.set_cell([12.41850041, 12.41850041, 12.41850041])
print(init_conf)
init_conf.set_calculator(calculator)
velocitydistribution.MaxwellBoltzmannDistribution(init_conf, temperature_K=Temp)

if os.path.exists(out + '.xyz'):
        print('output file: ' + out + ' exist')
        os.system('mv ' + out +  '.xyz' + ' back.xyz')
        os.system('rm md.log')
dyn = Langevin(init_conf, 0.5*units.fs, temperature_K=Temp, friction=5e-3)
def write_frame():
        dyn.atoms.write(out + '.xyz', append=True)
dyn.attach(write_frame, interval=100)
dyn.attach(MDLogger(dyn, init_conf, 'md.log', header=True, stress=False,
           peratom=True, mode='w'), interval=interval)
dyn.run(1000000)
print("MD finished!")
t2 = time.time()
t = t2-t1
print('Real running time ' + str(t) + ' s')
#sys = read(out+'.traj', index = ':')
#write(out + '.xyz' , sys,  format = 'extxyz')
