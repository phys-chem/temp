import numpy as np
from ase.io import read
from ase.geometry.analysis import Analysis
import matplotlib.pyplot as plt
plt.rcParams['figure.dpi'] = 600
#plt.rcParams["font.family"] = 'Times New Roman'
plt.rcParams["font.weight"] = "bold"
plt.rcParams["savefig.bbox"] = 'tight'
plt.rcParams["axes.labelsize"] = 18

name = 'mace_water1593_300K_NVT'
pairs = [ ['O'], ['O', 'H'], ['H'] ]

plt.figure(figsize=(8, 16))
for j in range(len(pairs) ):
    if len(pairs[j]) == 1:
        pair_name = pairs[j][0] + '-' + pairs[j][0]
    else:
        pair_name = pairs[j][0] + '-' + pairs[j][1]

    rdf = np.loadtxt(name + '_rdf_' + pair_name + '.txt')
    #print(max(rdf[0]), max(rdf[1]))    
#print(prob)
#plt.title()
    plt.subplot(3, 1, j+1)
    plt.plot(rdf[:, 0], rdf[:, 1])

    plt.xlabel('r (Å)')
    plt.ylabel(pair_name)        
    plt.ylim(0, 4)
plt.savefig(name + '.jpg')
