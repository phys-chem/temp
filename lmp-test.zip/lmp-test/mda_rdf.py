import MDAnalysis as mda
from MDAnalysis.analysis import rdf
from ase.io import read, write
import numpy as np
#from MDAnalysis.tests.datafiles import XYZ


def calc_rdf(name, data, pairs, cell, format='extxyz', nbins=600, ranges=(0.0, 6.0)):
    #name = 'nep_water1593_300K_NVT'
    #pairs = [ ['O', 'O'], ['O', 'H'], ['H', 'H'] ]

    #data = 'dump.xyz'
    if format != 'extxyz' or format != 'xyz':
        syss = read(data, index=':', format=format)
        write('temp.xyz', syss, format='xyz', append=False )
        data = 'temp.xyz'
    u = mda.Universe(data, topology_format='XYZ', all_coordinates=True)
    for i in range(len(pairs)):
        #u.dimensions = [12.41850041,12.41850041,12.41850041, 90, 90, 90]
        u.dimensions = cell
        ag1 = u.select_atoms('name ' + pairs[i][0])
        if len(pairs[i]) == 1:
            ag2 = ag1
            pair_name = pairs[i][0] + '-' + pairs[i][0]
        else:
            ag2 = u.select_atoms('name ' + pairs[i][1])
            pair_name = pairs[i][0] + '-' + pairs[i][1]
        #O = u.select_atoms('name O')
        pair = rdf.InterRDF(ag1, ag2, verbose=True, nbins=nbins, range=ranges )
        pair.run()
        pair.rdf[0] = 0
        rdf_txt = np.stack((pair.bins, pair.rdf), axis=-1)
        #print(rdf)
        np.savetxt(name + '_rdf_' + pair_name + '.txt', rdf_txt)

if __name__ == '__main__':
    name = 'mace_water1593_300K_NVT'
    pairs = [ ['O', 'O'], ['O', 'H'], ['H', 'H'] ]
    data = name + '.xyz'
    cell = [12.41850041,12.41850041,12.41850041, 90, 90, 90]
    calc_rdf(name=name, data=data, pairs=pairs, cell=cell, format='extxyz')
