#!/bin/bash

#SBATCH -n 2 #
#SBATCH -N 1 # num of node
#SBATCH -t 3-48:30 # max time:  D-HH:MM
#SBATCH -p gpu # list
#SBATCH --mem=20000
#SBATCH --gres=gpu:1
source ~/software/mace-venv/bin/activate
python md.py
