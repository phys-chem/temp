/nfs/scistore14/chenggrp/jichen/software/hpc_sdk237/Linux_x86_64/23.7/comm_libs/mpi/bin/mpirun -np 1 /nfs/scistore14/chenggrp/jichen/software/lammps-mace-gpu/lammps/build-kokkos-cuda/lmp -k on g 1 -sf kk -in in.lammps -in in.h2o

