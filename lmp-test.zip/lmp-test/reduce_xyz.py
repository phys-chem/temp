inteval = 10
fname = '100step-mace_water1593_300K_NVT.xyz'
out = 'mace_water1593_300K_NVT.xyz'
f1 = open(fname, 'r')
f2 = open(out, 'w')
flag = -1
while True:
    line = f1.readline()
    if not line:
        break
    flag = flag + 1
    print(flag)    
    natom = int(line.split()[0])
    for i in range(natom+1):
        line = line + f1.readline()

    if flag % 10 == 0:
        f2.write(line)

f1.close()
f2.close()
