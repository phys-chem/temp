import os
from ase.io import read, write, vasp
from ase.build.tools import sort
sys = read('ASAP-select-fps-n-200.xyz' , index=':', format='extxyz')
for i in range(20, 51):
    atoms = sys[i]
    atoms = sort(atoms)
    os.system('mkdir '  + str(i))
    write('POSCAR', atoms, format='vasp')
    #write('temp.xyz', atoms, format='extxyz')
    #atoms = read('temp.xyz', format='extxyz')
    #vasp.write_vasp('POSCAR', atoms)
    os.system('cp ' + 'INCAR POSCAR intel_vasp.sh POTCAR ' + str(i))

