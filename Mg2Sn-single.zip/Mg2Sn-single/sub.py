import os
for i in range(30, 41):
    pwd = os.getcwd()
    os.chdir(pwd+'/'+str(i))
    #print(pwd)
    os.system('(echo 102; echo 1; echo ' + str(0.02) + ')|vaspkit')
    os.system('sbatch intel_vasp.sh ')
    os.chdir(pwd)
